export default function Footer() {
  return (
    <footer className="text-center py-8 text-text-muted text-sm">
      <p>© 2025 Calcolatore dell'Interesse di Rischio | Stile PancakeSwap</p>
    </footer>
  );
}
