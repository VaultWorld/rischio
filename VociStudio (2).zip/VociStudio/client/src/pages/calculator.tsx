import CompoundInterestCalculator from "@/components/CompoundInterestCalculator";

export default function Calculator() {
  return <CompoundInterestCalculator />;
}
